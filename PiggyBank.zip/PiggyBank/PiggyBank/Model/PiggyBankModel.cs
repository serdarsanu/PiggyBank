﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PiggyBank.Model
{
    class PiggyBankModel
    {
        public string Name { get; set; }
        public double Value { get; set; }
        public double RawVolume { get; set; }
        public double Volume { get; set; }

    }
}
